This README file was generated on 2022-09-29 (YYYY-MM-DD) by Eirik Lund Flogard.
Last updated: 2022-09-29.


-------------------
GENERAL INFORMATION
-------------------

1. Title of Dataset: Labour Inspection Checklists Dataset (LICD)

2. DOI: https://doi.org/10.18710/7U6TZP

3. Contact Information
     Name: Eirik Lund Flogard
     Institution: Norwegian Labour Inspection Authority
     Email: eirik.flogard@arbeidstilsynet.no

4. Date of data collection: See metadata field, Date of Collection.

5. Geographic location: Main land Norway

6. Description of dataset:

The dataset is intended to use for machine learning to promote United Nations' sustainable development goal 8, target 8: "Protect labour rights and promote safe and secure working environments for all workers, including migrant workers, in particular women migrants, and those in precarious employment". It consists of 63634 instances with past inspections conducted by NLIA between 01/01/2012 and 01/06/2019. Each instance in LICD is described via 575 features and two target variables. Each feature represents either organisational or financial information about the inspected organisation. The first target variable is an identifier for the checklist that were used to inspect the organisation. The variable can be used in a machine learning model to predict the optimal checklist for a specific target organisation. The second target variable denotes whether non-compliance was found at the inspection. The variable can be used to in a machine learning to predict non-compliance to working environment regulations among potential target organisations for inspections. The features, target variables and column names of the dataset have been translated from Norwegian to English.

--------------------
DATA & FILE OVERVIEW
--------------------

File List: 
- 00Readme.txt (plain text file)
This file contains an overview and brief documentation of the dataset.

- Dataset documentation.pdf
This file contains more details regarding compositions, collection, processing, distribution and maintainance of the dataset.

- LICD.csv
The dataset is contained within the comma separated (.csv) file 

Is this a new version of a previously published dataset?: No
--------------------------
METHODOLOGICAL INFORMATION
--------------------------

Description of methods used for collection/generation and processing of data: 
See "Dataset documentation.pdf". Also the data set is described in the associated accepted NeurIPS Datasets and Benchmark paper (See under Related publication in the meta data field)

------------------------------
DATA-SPECIFIC INFORMATION FOR: LICD.csv
------------------------------

Each row in the dataset represents an inspection conducted by the Norwegian Labour Inspection Authority. Each row contains features/information about an inspected organisations and two target labels for machine learning, Checklist ID and NonCompliance.
The information about the inspected organisation is a "snapshot" from the time of the inspection.

1. Variable/Column List: 
- Industry Main Area Code: Categorical (letters). Each entry lists the industry main area code of the inspected organisation in the same row. See https://www.ssb.no/klass/klassifikasjoner/6
- Industry Code: Ordinal (Numbered categories). Lists the industry code of the inspected organisation. See https://www.ssb.no/klass/klassifikasjoner/6
- IsRegisteredVATregister: Binary, indicates whether the inspected organisation is listed in the Norwegian VAT register.
- IsRegisteredEmploymentregister: Binary, indicates whether the inspected organisation is listed in the Norwegian Employment Register.
- Business Age: Integer. Lists the business age (number of months) of the inspected organisation.
- Number of Employees: Integer. Lists the official number of employees of the insected organisation.
- NonCompliance: Binary. Indicates whether the inspected organisation is found to be non-compliant to health, environment and safety regulations (HSE).
- Checklist ID: Categorical target label(369 possible hexadecimal values). Each entry (row) contains the identifer of the checklist used to survey the inspected organisation
- Checklist Content: Categorical (369 different texts). Displays the content of the checklist used to survey the inspected target organisation.
- Currency code: Categorical. Indicates which currency an organisation's fiscal report is given in. Anything other than NOK is rare.
- Fiscal accounting type: Categorical. Indicates the type of fiscal accounting the inspected organisation adhere to.

There are 569 more columns which all contain financial (fiscal/balance) information about the inspected organisation. The values for these are given in number (float) format.


2. Missing data codes: 
Missing data are represented as "NULL".

3. Specialized formats or other abbreviations used: 
NLIA: Norwegian Labour Inspection Authority
LICD: Labour Inspection Checklists Dataset
HSE: Health, environment and Safety
VAT: Value added tax

--------------------------
SHARING/ACCESS INFORMATION
--------------------------
(See metadata record for dataset and Dataset documentation.pdf.)

1. Licenses/restrictions:  CC0. See Terms section.
2. Links to publications that cite or use the data: The dataset is presented and described in a dedicated paper. See metadata field "Related Publication".
3. Links/relationships to related data sets: See metadata field Related Datasets.
4. Data sources: See metadata field Data Sources.
5. Recommended citation: See metadata field "Related Publication". 
